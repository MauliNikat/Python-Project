# Music-Player-System-Using-Python
 
# Required libraries of our Project

pygame - This Library includes several modules for playing sound.

pygame mixer - Loading and playing sound from playlist.

tkinter - Tkinter is the standard GUI library for Python.

os - os module is used for creating,removing folders and fetching its content,changing and identifying.

PIL- ImageTk,Image -PIL stands for Python Imaging Library, and it's the original library that enabled Python to deal with images.

Aim of our Project - I have implemented code to create a playlist and playing songs using python
